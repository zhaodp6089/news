//
//  AppDelegate.h
//  news_learning
//
//  Created by admin on 2017/8/23.
//  Copyright © 2017年 com.taihe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

