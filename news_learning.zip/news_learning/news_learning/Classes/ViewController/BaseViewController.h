//
//  BaseViewController.h
//  news_learning
//
//  Created by admin on 2017/8/24.
//  Copyright © 2017年 com.taihe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
